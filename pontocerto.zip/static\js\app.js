/* Inicialização geral: abas, tema, modais, configurações e backup. */
const App = (() => {
  const $ = (s) => document.querySelector(s);
  let toastTimer;

  const icons = () => window.lucide && lucide.createIcons();
  function toast(msg, type = "ok") {
    const t = $("#toast");
    t.textContent = msg;
    t.className = `toast show ${type}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.className = "toast"), 2600);
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); }
    catch {
      const ta = Object.assign(document.createElement("textarea"), { value: text });
      document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove();
    }
  }
  function download(blob, name) {
    const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: name });
    a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  const openModal = (s) => { $(s).hidden = false; requestAnimationFrame(() => $(s).classList.add("open")); };
  const closeModal = (s) => { $(s).classList.remove("open"); setTimeout(() => ($(s).hidden = true), 200); };

  function applyTheme() { document.documentElement.dataset.theme = Store.settings().theme; }

  function initSettings() {
    const fill = () => {
      const s = Store.settings();
      $("#cfg-jornada").value = T.toHHMM(s.jornada);
      $("#cfg-almoco").value = s.almoco;
      $("#cfg-weekend").checked = !!s.sabado;
    };
    $("#btn-settings").addEventListener("click", () => { fill(); openModal("#modal-settings"); });
    document.querySelectorAll("[data-jornada]").forEach((c) => c.addEventListener("click", () => ($("#cfg-jornada").value = c.dataset.jornada)));
    $("#form-settings").addEventListener("submit", (e) => {
      e.preventDefault();
      Store.setSettings({ jornada: T.toMin($("#cfg-jornada").value), almoco: +$("#cfg-almoco").value, sabado: $("#cfg-weekend").checked });
      closeModal("#modal-settings"); toast("Configurações salvas", "ok");
    });
    $("#btn-export-json").addEventListener("click", () =>
      download(new Blob([JSON.stringify(Store.backup(), null, 2)], { type: "application/json" }), `PontoCerto_backup_${T.dateKey(new Date())}.json`));
    $("#input-import").addEventListener("change", async (e) => {
      const file = e.target.files[0]; if (!file) return;
      try {
        const data = JSON.parse(await file.text());
        if (confirm("Isso substituirá todos os dados atuais. Continuar?")) { Store.restore(data); applyTheme(); toast("Backup importado!", "ok"); }
      } catch (err) { toast(err.message || "Arquivo inválido", "warn"); }
      e.target.value = "";
    });
  }

  function init() {
    applyTheme();
    document.querySelectorAll(".tab").forEach((tab) => tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === tab));
      document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === `view-${tab.dataset.tab}`));
      if (tab.dataset.tab === "dashboard") Dashboard.render();
    }));
    $("#btn-theme").addEventListener("click", () => {
      Store.setSettings({ theme: Store.settings().theme === "dark" ? "light" : "dark" }); applyTheme();
    });
    document.querySelectorAll(".modal").forEach((m) => {
      m.addEventListener("click", (e) => { if (e.target === m || e.target.closest("[data-close]")) closeModal("#" + m.id); });
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") document.querySelectorAll(".modal.open").forEach((m) => closeModal("#" + m.id));
    });
    initSettings();
    Today.init();
    Dashboard.init();
    Store.onChange(() => { applyTheme(); Today.render(); Dashboard.render(); });
    icons();
    Cloud.init();
  }

  return { init, toast, copy, download, openModal, closeModal, icons };
})();

document.addEventListener("DOMContentLoaded", App.init);
