/* Sincronização com Supabase (Auth e-mail/senha + Postgres com RLS). */
const Cloud = (() => {
  const $ = (s) => document.querySelector(s);
  const K_OWNER = "pontocerto:owner";
  const K_PULL = "pontocerto:lastPull";
  const cfg = window.PC_CONFIG || {};
  const enabled = !!(cfg.url && cfg.key && window.supabase);
  const sb = enabled ? window.supabase.createClient(cfg.url, cfg.key) : null;
  let user = null, syncing = false, pushTimer = null;

  const toRow = (day, r) => ({
    user_id: user.id, day,
    entrada: r.entrada || null, saida_almoco: r.saidaAlmoco || null,
    retorno_almoco: r.retornoAlmoco || null, saida: r.saida || null,
    tipo: r.tipo || "normal", justificativa: r.justificativa || null,
    deleted: !!r.deleted, updated_at: r.updatedAt || new Date().toISOString(),
  });
  const fromRow = (row) => {
    if (row.deleted) return { deleted: true, updatedAt: row.updated_at };
    const r = { updatedAt: row.updated_at };
    if (row.entrada) r.entrada = row.entrada;
    if (row.saida_almoco) r.saidaAlmoco = row.saida_almoco;
    if (row.retorno_almoco) r.retornoAlmoco = row.retorno_almoco;
    if (row.saida) r.saida = row.saida;
    if (row.tipo && row.tipo !== "normal") r.tipo = row.tipo;
    if (row.justificativa) r.justificativa = row.justificativa;
    return r;
  };

  function setStatus(state) {
    const el = $("#sync-status");
    if (!el) return;
    const map = {
      off: ["cloud-off", "Offline"], sync: ["refresh-cw", "Sincronizando"],
      ok: ["cloud", "Sincronizado"], pending: ["cloud-upload", "Pendente"], err: ["alert-triangle", "Erro de sync"],
    };
    const [icon, label] = map[state];
    el.className = `sync-pill ${state}`;
    el.innerHTML = `<i data-lucide="${icon}"></i><span>${label}</span>`;
    el.title = user ? `${label} · ${user.email}` : label;
    App.icons();
  }

  async function push() {
    const d = Store.dirty();
    const keys = [...d.keys];
    if (keys.length) {
      const rows = keys.map((k) => Store.raw(k)).map((r, i) => r && toRow(keys[i], r)).filter(Boolean);
      const { error } = await sb.from("time_records").upsert(rows, { onConflict: "user_id,day" });
      if (error) throw error;
    }
    if (d.settings) {
      const s = Store.settings();
      const { error } = await sb.from("user_settings").upsert({
        user_id: user.id, jornada: s.jornada, almoco: s.almoco, sabado: s.sabado, theme: s.theme, updated_at: new Date().toISOString(),
      });
      if (error) throw error;
    }
    Store.clearDirty(keys, d.settings);
  }

  async function pull() {
    const since = localStorage.getItem(K_PULL);
    const started = new Date().toISOString();
    let q = sb.from("time_records").select("*");
    if (since) q = q.gt("updated_at", since);
    const { data, error } = await q;
    if (error) throw error;
    const recs = Object.fromEntries((data || []).map((row) => [row.day, fromRow(row)]));
    let settings = null;
    if (!since) {
      const res = await sb.from("user_settings").select("*").maybeSingle();
      if (res.error) throw res.error;
      if (res.data) settings = { jornada: res.data.jornada, almoco: res.data.almoco, sabado: res.data.sabado, theme: res.data.theme };
    }
    Store.applyRemote(recs, settings);
    localStorage.setItem(K_PULL, started);
  }

  async function sync(manual = false) {
    if (!user || syncing) return;
    if (!navigator.onLine) { setStatus("off"); if (manual) App.toast("Sem internet. Os dados serão enviados ao reconectar.", "warn"); return; }
    syncing = true; setStatus("sync");
    try {
      await push();
      await pull();
      setStatus("ok");
      if (manual) App.toast("Sincronizado com a nuvem ☁️", "ok");
    } catch (e) {
      console.error(e); setStatus("err");
      if (manual) App.toast("Erro ao sincronizar: " + (e.message || e), "warn");
    } finally { syncing = false; }
  }

  const schedulePush = () => {
    if (!user) return;
    setStatus(navigator.onLine ? "pending" : "off");
    clearTimeout(pushTimer);
    pushTimer = setTimeout(() => sync(), 1200);
  };

  /* ---------- Auth ---------- */
  function showAuth(show) {
    $("#auth-screen").hidden = !show;
    document.body.classList.toggle("locked", show);
  }

  async function onSignedIn(u) {
    user = u;
    const prev = localStorage.getItem(K_OWNER);
    if (prev && prev !== u.id) { Store.resetLocal(); localStorage.removeItem(K_PULL); }
    else if (!prev) { Store.markAllDirty(); localStorage.removeItem(K_PULL); } // dados locais anteriores sobem para a conta
    localStorage.setItem(K_OWNER, u.id);
    $("#account-email").textContent = u.email;
    $("#account-box").hidden = false;
    showAuth(false);
    await sync();
  }

  async function handleAuth(e) {
    e.preventDefault();
    const mode = e.submitter?.dataset.mode || "login";
    const email = $("#auth-email").value.trim();
    const password = $("#auth-password").value;
    const btns = $("#form-auth").querySelectorAll("button");
    btns.forEach((b) => (b.disabled = true));
    $("#auth-msg").textContent = "";
    try {
      if (mode === "signup") {
        const { data, error } = await sb.auth.signUp({ email, password });
        if (error) throw error;
        if (!data.session) { $("#auth-msg").textContent = "Conta criada! Confirme pelo link enviado ao seu e-mail e depois entre."; return; }
      } else if (mode === "reset") {
        if (!email) throw new Error("Informe seu e-mail");
        const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin });
        if (error) throw error;
        $("#auth-msg").textContent = "Enviamos um link para redefinir sua senha.";
        return;
      } else {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) {
      const msg = { "Invalid login credentials": "E-mail ou senha incorretos", "Email not confirmed": "Confirme seu e-mail antes de entrar" }[err.message] || err.message;
      $("#auth-msg").textContent = msg;
    } finally { btns.forEach((b) => (b.disabled = false)); }
  }

  async function logout() {
    if (Store.dirty().keys.length && !confirm("Há registros ainda não sincronizados. Sair mesmo assim?")) return;
    await sb.auth.signOut();
    Store.resetLocal();
    localStorage.removeItem(K_OWNER); localStorage.removeItem(K_PULL);
    user = null;
    $("#account-box").hidden = true;
    App.closeModal("#modal-settings");
    showAuth(true);
  }

  async function init() {
    Store.onLocalChange(schedulePush);
    if (!enabled) { $("#sync-status").hidden = true; $("#cloud-section").hidden = true; return; }
    $("#form-auth").addEventListener("submit", handleAuth);
    $("#btn-offline").addEventListener("click", () => showAuth(false));
    $("#btn-logout").addEventListener("click", logout);
    $("#btn-sync").addEventListener("click", () => sync(true));
    $("#sync-status").addEventListener("click", () => (user ? sync(true) : showAuth(true)));
    window.addEventListener("online", () => sync());
    window.addEventListener("offline", () => setStatus("off"));
    document.addEventListener("visibilitychange", () => document.visibilityState === "visible" && sync());

    sb.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY") {
        const p = prompt("Digite sua nova senha (mín. 6 caracteres):");
        if (p) sb.auth.updateUser({ password: p }).then(({ error }) => App.toast(error ? error.message : "Senha alterada!", error ? "warn" : "ok"));
      }
      if (event === "SIGNED_IN" && session && (!user || user.id !== session.user.id)) onSignedIn(session.user);
    });

    const { data } = await sb.auth.getSession();
    if (data.session) onSignedIn(data.session.user);
    else { setStatus("off"); showAuth(true); }
  }

  return { init, sync };
})();
