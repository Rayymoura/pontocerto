/* Aba 2: Dashboard Mensal & Banco de Horas */
const Dashboard = (() => {
  const $ = (s) => document.querySelector(s);
  const TYPE_LABEL = { folga: "Folga", ferias: "Férias", feriado: "Feriado", atestado: "Atestado", falta: "Falta" };
  let cur = new Date(); cur.setDate(1);
  let editingKey = null;

  function monthRows() {
    const s = Store.settings();
    const y = cur.getFullYear(), m = cur.getMonth();
    const days = new Date(y, m + 1, 0).getDate();
    const todayK = T.dateKey(new Date());
    const rows = [];
    for (let d = 1; d <= days; d++) {
      const date = new Date(y, m, d);
      const key = T.dateKey(date);
      const r = Store.get(key);
      const isToday = key === todayK;
      const future = key > todayK;
      const tipo = r?.tipo || "normal";
      const w = T.worked(r, isToday && r && !r.saida && !(r.saidaAlmoco && !r.retornoAlmoco) ? T.nowMin() : null);
      const goal = T.target(key, r, s);
      let color = "", counts = false, bal = 0;

      if (T.OFF_TYPES.includes(tipo)) { color = "blue"; counts = true; bal = w - goal; }
      else if (tipo === "falta") { color = "red"; counts = true; bal = -goal; }
      else if (T.hasAny(r)) {
        bal = w - goal;
        if (!T.isComplete(r)) { color = "yellow"; counts = !isToday; }
        else { counts = true; color = bal >= -15 ? "green" : bal <= -60 ? "red" : "yellow"; }
      } else if (goal === 0) color = "weekend";
      else if (!future && !isToday) color = "empty";

      rows.push({ key, date, r, tipo, w, goal, bal, color, counts, isToday, future });
    }
    return rows;
  }

  function render() {
    const rows = monthRows();
    const lbl = cur.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
    $("#month-label").textContent = lbl.charAt(0).toUpperCase() + lbl.slice(1);

    const counted = rows.filter((x) => x.counts);
    const bank = counted.reduce((a, x) => a + x.bal, 0);
    const workedDays = rows.filter((x) => x.w > 0);
    const avg = workedDays.length ? workedDays.reduce((a, x) => a + x.w, 0) / workedDays.length : 0;
    const sb = $("#s-bank");
    sb.textContent = T.fmtDur(bank, true);
    sb.className = `mono ${bank >= 0 ? "pos" : "neg"}`;
    $("#s-days").textContent = workedDays.length;
    $("#s-avg").textContent = T.fmtDur(avg);

    $("#month-body").innerHTML = rows.map((x) => {
      const cells = T.FIELDS.map((f) => `<td class="mono">${x.r?.[f] || "—"}</td>`).join("");
      const tag = TYPE_LABEL[x.tipo] ? `<span class="tag ${x.color}">${TYPE_LABEL[x.tipo]}</span>` : "";
      const just = x.r?.justificativa ? `<i data-lucide="message-square-text" class="just" title="${x.r.justificativa.replace(/"/g, "&quot;")}"></i>` : "";
      const balTxt = x.counts || x.w ? `<span class="${x.bal >= 0 ? "pos" : "neg"}">${T.fmtDur(x.bal, true)}</span>` : "—";
      return `<tr class="row-${x.color}${x.isToday ? " today" : ""}">
        <td data-label="Data"><span class="dot ${x.color}"></span>${String(x.date.getDate()).padStart(2, "0")}/${String(x.date.getMonth() + 1).padStart(2, "0")} ${tag}${just}</td>
        <td data-label="Dia">${T.WEEKDAYS[x.date.getDay()].slice(0, 3)}</td>
        ${cells}
        <td class="mono" data-label="Total">${x.w ? T.fmtDur(x.w) : "—"}</td>
        <td class="mono">${balTxt}</td>
        <td><button class="icon-btn sm" data-edit="${x.key}" title="Editar"><i data-lucide="square-pen"></i></button></td>
      </tr>`;
    }).join("");
    // rótulos para layout mobile em cards
    $("#month-body").querySelectorAll("tr").forEach((tr) => {
      const labels = ["Data", "Dia", "Entrada", "Saída Alm.", "Retorno", "Saída", "Total", "Saldo", ""];
      tr.querySelectorAll("td").forEach((td, i) => td.setAttribute("data-label", labels[i]));
    });
    App.icons();
  }

  /* ---------- Modal ---------- */
  function openEdit(key) {
    editingKey = key;
    const r = Store.get(key) || {};
    const d = new Date(key + "T12:00:00");
    $("#edit-title").textContent = `${T.WEEKDAYS[d.getDay()]}, ${T.fmtDateBR(key)}`;
    $("#f-tipo").value = r.tipo || "normal";
    T.FIELDS.forEach((f) => ($(`#f-${f}`).value = r[f] || ""));
    $("#f-just").value = r.justificativa || "";
    toggleTimes();
    App.openModal("#modal-edit");
  }
  const toggleTimes = () => $("#f-times").classList.toggle("dim", $("#f-tipo").value !== "normal");

  function saveEdit(e) {
    e.preventDefault();
    const data = { tipo: $("#f-tipo").value, justificativa: $("#f-just").value.trim() };
    T.FIELDS.forEach((f) => (data[f] = data.tipo === "normal" ? $(`#f-${f}`).value : ""));
    const e1 = T.toMin(data.entrada), s1 = T.toMin(data.saida);
    if (data.saidaAlmoco && !data.retornoAlmoco && data.saida) return App.toast("Informe o retorno do almoço", "warn");
    if (e1 != null && s1 != null && s1 <= e1 && !confirm("Saída antes da entrada. Considerar virada de meia-noite?")) return;
    Store.set(editingKey, data);
    App.closeModal("#modal-edit");
    App.toast("Registro salvo", "ok");
  }

  /* ---------- Exportações ---------- */
  const fname = (ext) => `PontoCerto_${cur.getFullYear()}-${String(cur.getMonth() + 1).padStart(2, "0")}.${ext}`;
  const tableData = () => monthRows().map((x) => [
    T.fmtDateBR(x.key), T.WEEKDAYS[x.date.getDay()],
    ...T.FIELDS.map((f) => x.r?.[f] || ""),
    x.w ? T.fmtDur(x.w) : "", x.counts || x.w ? T.fmtDur(x.bal, true) : "",
    [TYPE_LABEL[x.tipo] || "", x.r?.justificativa || ""].filter(Boolean).join(" - "),
  ]);
  const HEAD = ["Data", "Dia", "Entrada", "Saída Almoço", "Retorno Almoço", "Saída", "Total", "Saldo", "Observação"];

  function exportCSV() {
    const esc = (v) => `"${String(v).replace(/"/g, '""')}"`;
    const csv = [HEAD, ...tableData()].map((r) => r.map(esc).join(";")).join("\r\n");
    App.download(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" }), fname("csv"));
  }

  function exportPDF() {
    if (!window.jspdf) return App.toast("Biblioteca de PDF indisponível (sem internet?)", "warn");
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
    const s = Store.settings();
    doc.setFontSize(18); doc.setTextColor(40, 40, 70);
    doc.text("PontoCerto — Espelho de Ponto", 14, 16);
    doc.setFontSize(10); doc.setTextColor(100);
    doc.text(`Período: ${$("#month-label").textContent}   |   Jornada: ${T.fmtDur(s.jornada)}   |   Banco: ${$("#s-bank").textContent}   |   Dias trabalhados: ${$("#s-days").textContent}   |   Média: ${$("#s-avg").textContent}`, 14, 23);
    const rows = monthRows();
    doc.autoTable({
      head: [HEAD], body: tableData(), startY: 28, theme: "grid",
      styles: { fontSize: 8, cellPadding: 1.6 },
      headStyles: { fillColor: [99, 102, 241] },
      didParseCell: (d) => {
        if (d.section !== "body") return;
        const c = rows[d.row.index].color;
        const fill = { green: [232, 248, 238], yellow: [254, 248, 225], blue: [230, 240, 254], red: [254, 233, 233], weekend: [244, 244, 246] }[c];
        if (fill) d.cell.styles.fillColor = fill;
      },
    });
    const y = doc.lastAutoTable.finalY + 18;
    doc.setDrawColor(150);
    doc.line(20, y, 110, y); doc.line(180, y, 270, y);
    doc.setFontSize(9);
    doc.text("Assinatura do colaborador", 45, y + 5); doc.text("Assinatura do gestor", 210, y + 5);
    doc.text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, 14, 200);
    doc.save(fname("pdf"));
  }

  function init() {
    $("#btn-prev-month").addEventListener("click", () => { cur.setMonth(cur.getMonth() - 1); render(); });
    $("#btn-next-month").addEventListener("click", () => { cur.setMonth(cur.getMonth() + 1); render(); });
    $("#month-body").addEventListener("click", (e) => { const b = e.target.closest("[data-edit]"); if (b) openEdit(b.dataset.edit); });
    $("#f-tipo").addEventListener("change", toggleTimes);
    $("#form-edit").addEventListener("submit", saveEdit);
    $("#btn-delete-day").addEventListener("click", () => {
      if (confirm("Apagar este registro?")) { Store.remove(editingKey); App.closeModal("#modal-edit"); }
    });
    $("#btn-csv").addEventListener("click", exportCSV);
    $("#btn-pdf").addEventListener("click", exportPDF);
    render();
    setInterval(() => { if (document.querySelector("#view-dashboard.active")) render(); }, 60000);
  }

  return { init, render };
})();
