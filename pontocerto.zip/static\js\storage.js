/* Persistência offline-first em localStorage, com marcação para sincronização. */
const Store = (() => {
  const K_REC = "pontocerto:records";
  const K_CFG = "pontocerto:settings";
  const K_DIRTY = "pontocerto:dirty";
  const DEFAULTS = { jornada: 480, almoco: 60, sabado: false, theme: "dark" };

  const read = (k, fb) => { try { return JSON.parse(localStorage.getItem(k)) ?? fb; } catch { return fb; } };
  let records = read(K_REC, {});            // inclui "lápides" { deleted: true }
  let settings = { ...DEFAULTS, ...read(K_CFG, {}) };
  let dirty = read(K_DIRTY, { keys: [], settings: false });

  const listeners = new Set();
  const changeHooks = new Set();
  const emit = () => listeners.forEach((fn) => fn());
  const persist = () => {
    localStorage.setItem(K_REC, JSON.stringify(records));
    localStorage.setItem(K_CFG, JSON.stringify(settings));
    localStorage.setItem(K_DIRTY, JSON.stringify(dirty));
  };
  const markDirty = (key) => { if (!dirty.keys.includes(key)) dirty.keys.push(key); };
  const local = (fn) => { fn(); persist(); emit(); changeHooks.forEach((h) => h()); };
  const live = (r) => (r && !r.deleted ? r : null);

  return {
    onChange: (fn) => listeners.add(fn),
    onLocalChange: (fn) => changeHooks.add(fn),
    get: (key) => live(records[key]),
    all: () => Object.fromEntries(Object.entries(records).filter(([, r]) => !r.deleted)),
    set(key, data) {
      local(() => {
        const r = { ...(live(records[key]) || {}), ...data };
        Object.keys(r).forEach((k) => (r[k] === "" || r[k] == null) && delete r[k]);
        delete r.updatedAt; delete r.deleted;
        const empty = Object.keys(r).length === 0 || (Object.keys(r).length === 1 && r.tipo === "normal");
        records[key] = empty ? { deleted: true, updatedAt: new Date().toISOString() } : { ...r, updatedAt: new Date().toISOString() };
        markDirty(key);
      });
    },
    remove(key) { local(() => { records[key] = { deleted: true, updatedAt: new Date().toISOString() }; markDirty(key); }); },
    settings: () => settings,
    setSettings(s) { local(() => { settings = { ...settings, ...s }; dirty.settings = true; }); },

    /* ---- usados pela sincronização ---- */
    raw: (key) => records[key],
    dirty: () => dirty,
    clearDirty(keys, settingsToo) {
      dirty.keys = dirty.keys.filter((k) => !keys.includes(k));
      if (settingsToo) dirty.settings = false;
      persist();
    },
    applyRemote(remoteRecords, remoteSettings) {
      let changed = false;
      for (const [key, r] of Object.entries(remoteRecords)) {
        const cur = records[key];
        if (!cur || !cur.updatedAt || new Date(r.updatedAt) > new Date(cur.updatedAt)) {
          records[key] = r; changed = true;
          dirty.keys = dirty.keys.filter((k) => k !== key);
        }
      }
      if (remoteSettings && !dirty.settings) { settings = { ...settings, ...remoteSettings }; changed = true; }
      if (changed) { persist(); emit(); }
    },
    resetLocal() { records = {}; settings = { ...DEFAULTS, theme: settings.theme }; dirty = { keys: [], settings: false }; persist(); emit(); },
    markAllDirty() { dirty.keys = Object.keys(records); dirty.settings = true; persist(); },

    backup: () => ({ app: "PontoCerto", version: 2, exportedAt: new Date().toISOString(), settings, records: Store.all() }),
    restore(data) {
      if (!data || typeof data.records !== "object") throw new Error("Arquivo de backup inválido");
      local(() => {
        const now = new Date().toISOString();
        Object.keys(records).forEach((k) => { if (!data.records[k]) { records[k] = { deleted: true, updatedAt: now }; markDirty(k); } });
        Object.entries(data.records).forEach(([k, r]) => { records[k] = { ...r, updatedAt: now }; markDirty(k); });
        settings = { ...DEFAULTS, ...(data.settings || {}) };
        dirty.settings = true;
      });
    },
  };
})();
