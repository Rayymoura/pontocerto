/* Regras de negócio: tudo é convertido para minutos. */
const T = (() => {
  const FIELDS = ["entrada", "saidaAlmoco", "retornoAlmoco", "saida"];
  const LABELS = { entrada: "Entrada", saidaAlmoco: "Saída Almoço", retornoAlmoco: "Retorno Almoço", saida: "Saída" };
  const WEEKDAYS = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  const OFF_TYPES = ["folga", "ferias", "feriado", "atestado"];

  const toMin = (hhmm) => {
    if (!hhmm) return null;
    const [h, m] = hhmm.split(":").map(Number);
    return h * 60 + m;
  };
  const toHHMM = (min) => {
    min = ((Math.round(min) % 1440) + 1440) % 1440;
    return `${String(Math.floor(min / 60)).padStart(2, "0")}:${String(min % 60).padStart(2, "0")}`;
  };
  /** Duração formatada "08h00m" (com sinal opcional). */
  const fmtDur = (min, signed = false) => {
    const sign = min < 0 ? "-" : signed && min > 0 ? "+" : "";
    const a = Math.abs(Math.round(min));
    return `${sign}${String(Math.floor(a / 60)).padStart(2, "0")}h${String(a % 60).padStart(2, "0")}m`;
  };
  const nowMin = (d = new Date()) => d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60;
  const dateKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const fmtDateBR = (key) => key.split("-").reverse().join("/");
  const span = (a, b) => (b >= a ? b - a : b + 1440 - a); // suporta virada de meia-noite

  /**
   * Minutos trabalhados. O intervalo entre Saída e Retorno do almoço NÃO conta.
   * `live` = minuto atual (para contar jornada em andamento) ou null.
   */
  function worked(r, live = null) {
    if (!r) return 0;
    const e = toMin(r.entrada), sa = toMin(r.saidaAlmoco), ra = toMin(r.retornoAlmoco), s = toMin(r.saida);
    if (e == null) return 0;
    if (sa != null) {
      let total = span(e, sa);
      if (ra != null) {
        const end = s ?? live;
        if (end != null) total += span(ra, end);
      }
      return total;
    }
    const end = s ?? live;
    return end != null ? span(e, end) : 0;
  }

  /** Meta do dia em minutos, conforme tipo e dia da semana. */
  function target(key, r, settings) {
    const tipo = r?.tipo || "normal";
    if (OFF_TYPES.includes(tipo)) return 0;
    if (tipo === "falta") return settings.jornada;
    const dow = new Date(key + "T12:00:00").getDay();
    const workday = dow >= 1 && dow <= 5 || (dow === 6 && settings.sabado);
    // Fim de semana trabalhado: tudo vira hora extra
    return workday ? settings.jornada : 0;
  }

  /** Horário ideal de saída = Entrada + almoço (real ou padrão) + jornada. */
  function idealExit(r, settings) {
    const e = toMin(r?.entrada);
    if (e == null) return null;
    const sa = toMin(r.saidaAlmoco), ra = toMin(r.retornoAlmoco);
    let lunch = settings.almoco;
    if (sa != null && ra != null) lunch = span(sa, ra);
    else if (sa != null) lunch = Math.max(settings.almoco, span(sa, nowMin()));
    return e + lunch + settings.jornada;
  }

  const isComplete = (r) => !!(r?.entrada && r?.saida && (!!r.saidaAlmoco === !!r.retornoAlmoco));
  const hasAny = (r) => FIELDS.some((f) => r?.[f]);

  return { FIELDS, LABELS, WEEKDAYS, OFF_TYPES, toMin, toHHMM, fmtDur, nowMin, dateKey, fmtDateBR, worked, target, idealExit, isComplete, hasAny };
})();
