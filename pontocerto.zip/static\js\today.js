/* Aba 1: Registro Rápido */
const Today = (() => {
  const $ = (s) => document.querySelector(s);
  const todayKey = () => T.dateKey(new Date());

  function status(r) {
    if (r && T.OFF_TYPES.includes(r.tipo)) return ["Dia de folga", "blue"];
    if (!r?.entrada) return ["Aguardando Entrada", "muted"];
    if (r.saida) return ["Jornada Concluída", "green"];
    if (r.retornoAlmoco) return ["Pendente Saída", "yellow"];
    if (r.saidaAlmoco) return ["Em Almoço · Pendente Retorno", "yellow"];
    return ["Em Aberto · Pendente Saída Almoço", "purple"];
  }

  function nextField(r) {
    if (!r?.entrada) return "entrada";
    if (r.saida) return null;
    if (!r.saidaAlmoco) return "saidaAlmoco";
    if (!r.retornoAlmoco) return "retornoAlmoco";
    return "saida";
  }

  function punch(field) {
    const r = Store.get(todayKey()) || {};
    if (r[field]) return;
    // Permite pular almoço: "Saída" direto após a entrada
    if (field === "retornoAlmoco" && !r.saidaAlmoco) return App.toast("Registre a saída do almoço primeiro", "warn");
    if (field !== "entrada" && !r.entrada) return App.toast("Registre a entrada primeiro", "warn");
    if (field === "saida" && r.saidaAlmoco && !r.retornoAlmoco) return App.toast("Registre o retorno do almoço primeiro", "warn");
    const now = T.toHHMM(T.nowMin());
    Store.set(todayKey(), { [field]: now });
    App.toast(`${T.LABELS[field]} registrada às ${now}`, "ok");
    if (navigator.vibrate) navigator.vibrate(40);
  }

  function renderStatic() {
    const r = Store.get(todayKey());
    const next = nextField(r);
    T.FIELDS.forEach((f) => {
      const btn = $(`#punch-${f}`);
      const done = !!r?.[f];
      btn.disabled = done || (!next) ;
      btn.classList.toggle("done", done);
      btn.classList.toggle("next", f === next || (next === "saidaAlmoco" && f === "saida" && false));
      btn.querySelector(".punch-time").textContent = r?.[f] || "--:--";
      const input = $(`#edit-${f}`);
      if (document.activeElement !== input) input.value = r?.[f] || "";
    });
    // Após a entrada, "Saída" fica disponível também (dia sem almoço)
    if (r?.entrada && !r.saidaAlmoco && !r.saida) $("#punch-saida").disabled = false;
    const [txt, color] = status(r);
    const b = $("#status-badge");
    b.textContent = txt;
    b.className = `badge ${color}`;
    tick();
  }

  function tick() {
    const d = new Date();
    $("#clock").textContent = d.toLocaleTimeString("pt-BR", { hour12: false });
    const ds = d.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" });
    $("#clock-date").textContent = ds.charAt(0).toUpperCase() + ds.slice(1);

    const s = Store.settings();
    const key = todayKey();
    const r = Store.get(key);
    const live = r?.saida ? null : T.nowMin(d);
    const onLunch = r?.saidaAlmoco && !r?.retornoAlmoco;
    const w = T.worked(r, onLunch ? null : live);
    const goal = T.target(key, r, s);
    const bal = w - goal;

    $("#m-worked").textContent = T.fmtDur(w);
    $("#m-progress").style.width = `${goal ? Math.min(100, (w / goal) * 100) : (w ? 100 : 0)}%`;
    const ideal = T.idealExit(r, s);
    $("#m-ideal").textContent = ideal != null ? T.toHHMM(ideal) : "--:--";
    $("#m-ideal-hint").textContent = ideal != null
      ? (r?.saida ? `Saiu às ${r.saida}` : `Faltam ${T.fmtDur(Math.max(0, goal - w))}`)
      : `Meta: ${T.fmtDur(s.jornada)}`;
    const mb = $("#m-balance");
    mb.textContent = T.fmtDur(bal, true);
    mb.className = `metric-value mono ${bal >= 0 ? "pos" : "neg"}`;
  }

  function whatsapp() {
    const key = todayKey();
    const r = Store.get(key) || {};
    const s = Store.settings();
    const w = T.worked(r, r.saida ? null : T.nowMin());
    const bal = w - T.target(key, r, s);
    const txt = [
      `*📌 Ponto de Hoje (${T.fmtDateBR(key)}):*`,
      ...T.FIELDS.map((f) => `• ${T.LABELS[f]}: ${r[f] || "--:--"}`),
      `⏱ Total: ${T.fmtDur(w)} | Saldo: ${T.fmtDur(bal, true)}`,
    ].join("\n");
    App.copy(txt).then(() => App.toast("Resumo copiado! Cole no WhatsApp 📲", "ok"));
  }

  function init() {
    document.querySelectorAll(".punch").forEach((b) => b.addEventListener("click", () => punch(b.dataset.field)));
    document.querySelectorAll(".edit-grid input[data-field]").forEach((inp) =>
      inp.addEventListener("change", () => {
        Store.set(todayKey(), { [inp.dataset.field]: inp.value });
        App.toast("Horário ajustado", "ok");
      })
    );
    $("#btn-clear-today").addEventListener("click", () => {
      if (confirm("Apagar todos os registros de hoje?")) Store.remove(todayKey());
    });
    $("#btn-whatsapp").addEventListener("click", whatsapp);
    let lastKey = todayKey();
    setInterval(() => {
      if (todayKey() !== lastKey) { lastKey = todayKey(); renderStatic(); } else tick();
    }, 1000);
    renderStatic();
  }

  return { init, render: renderStatic };
})();
