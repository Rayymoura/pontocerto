-- PontoCerto - schema Supabase
-- Execute no Supabase: SQL Editor -> New query -> cole e rode.

create table if not exists public.time_records (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  day date not null,
  entrada text,
  saida_almoco text,
  retorno_almoco text,
  saida text,
  tipo text not null default 'normal',
  justificativa text,
  deleted boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, day)
);

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade default auth.uid(),
  jornada int not null default 480,
  almoco int not null default 60,
  sabado boolean not null default false,
  theme text not null default 'dark',
  updated_at timestamptz not null default now()
);

alter table public.time_records enable row level security;
alter table public.user_settings enable row level security;

drop policy if exists "own records" on public.time_records;
create policy "own records" on public.time_records
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "own settings" on public.user_settings;
create policy "own settings" on public.user_settings
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists time_records_updated on public.time_records (user_id, updated_at);
